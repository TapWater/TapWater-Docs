require 'test_helper'

class DrinksHelperTest < ActionView::TestCase
end
