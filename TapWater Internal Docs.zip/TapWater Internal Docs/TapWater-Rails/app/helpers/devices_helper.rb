module DevicesHelper
end
